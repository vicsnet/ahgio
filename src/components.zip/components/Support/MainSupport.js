import React from "react";
import Support from './Support'

function MainSupport() {
    return <div>
      <Support />
  </div>;
}

export default MainSupport;
